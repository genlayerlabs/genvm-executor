# GenSwap IC loader (script/verify/ic_zip.py). GenVM stores ZIP entries uncompressed, so the intelligent contract is
# contract/zip_probe.py.xz, the committed genlayer/zip_probe.py compressed with lzma. This decompresses it, refuses to run it unless
# its sha256 is the one below, and runs it as this package's own code: its contract class is defined here, as if the
# source were this file. Check: unzip the deployed code, xz -d the blob, compare its sha256 with git's file.
def __genswap_load():
    import hashlib, lzma
    name, want = "zip_probe.py", "2fdbbddf6c6d5b2d09a5a7446cefdf87671e843e463e4504aa41b09cf08d593c"
    with open(__file__.rsplit("/", 1)[0] + "/" + name + ".xz", "rb") as f:
        source = lzma.decompress(f.read())
    got = hashlib.sha256(source).hexdigest()
    if got != want:
        raise Exception("contract/" + name + ".xz is not the source it names: sha256 " + got + ", expected " + want)
    return compile(source, "/contract/" + name, "exec", dont_inherit=True)


exec(__genswap_load(), globals())
del __genswap_load
