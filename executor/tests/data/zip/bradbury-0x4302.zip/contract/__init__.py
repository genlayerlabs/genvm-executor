import genlayer as gl
from genlayer.storage import DynArray

from . import lib


class Contract(gl.contract.Contract):
	log: DynArray[str]

	def __init__(self):
		self.log.append(lib.event_binding())

	@gl.public.view
	def report(self) -> list[str]:
		return list(self.log)
