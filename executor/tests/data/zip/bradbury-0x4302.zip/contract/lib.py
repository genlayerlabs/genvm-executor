import genlayer as gl
from genlayer.types import Address, u256


class Transfer(gl.chain.Event):
	def __init__(self, to: Address, amount: u256, /): ...


def event_binding() -> str:
	ev = Transfer(Address('0x5B38Da6a701c568545dCfcB03FcB875f56beddC4'), 7)
	ev.emit()
	return f'multi-file #56 event Transfer(alice, 7): {ev._blob}'
